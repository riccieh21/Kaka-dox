# NIGHTFALL OSINT AI

A passive, defensive OSINT research dashboard built with Python 3.11+ and Streamlit.

## Modules
- Public IP metadata at approximate city/region level, ASN/ISP, reverse DNS, and reputation-provider links.
- Curated public username profile URL checks (heuristic; not identity verification).
- Domain RDAP metadata, DNS records, passive certificate-transparency names, and TLS certificate inspection.
- Local phishing URL heuristics; no URL fetching or crawling.
- SQLite investigation cases, evidence snapshots, citations, and Markdown/JSON reports.
- Privacy self-audit checklist and breach-response guidance.

## Safety
For lawful research and systems you own or are authorized to assess. The app does not expose residential addresses, collect credentials, query leaked password dumps, brute-force accounts/subdomains, exploit systems, or perform non-consensual tracking. IP geolocation is approximate. Username checks can be wrong. Provider data may be incomplete or stale.

## Setup
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```
Open http://localhost:8501.

## Sources
- IP metadata: ipapi.co
- Registration metadata: RDAP via rdap.org
- Passive certificate names: crt.sh
- DNS: system-configured recursive resolver
- TLS: direct TLS handshake to the domain on port 443
- Reputation: manual links to AbuseIPDB, VirusTotal and Cisco Talos; no unsupported verdict is generated.

## Data and deployment
SQLite data is stored in `.nightfall/nightfall.db`. Restrict host access and filesystem permissions. Before deployment, place behind SSO/authenticated reverse proxy, enable TLS, apply outbound allowlists and rate limits, define retention, encrypt backups, and audit dependencies. Do not expose the development server directly to the internet.

## Tests
```bash
python -m unittest discover -s tests -v
```
