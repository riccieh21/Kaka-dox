import streamlit as st
from nightfall.db import init_db, list_cases, create_case, add_evidence, list_evidence
from nightfall.services.ip_intel import investigate_ip
from nightfall.services.domain_intel import investigate_domain, lookup_dns, inspect_tls
from nightfall.services.username import check_username
from nightfall.services.phishing import analyze_url
from nightfall.reports import render_markdown_report, render_json_report
from nightfall.validation import normalize_ip, normalize_domain, normalize_username

st.set_page_config(page_title="NIGHTFALL OSINT AI", page_icon="🌑", layout="wide")
init_db()
st.markdown("""
<style>
.stApp{background:#050505;color:#f3f3f3}
[data-testid="stSidebar"]{background:#090909;border-right:1px solid #6f1515}
h1,h2,h3{color:#ff3434!important}
div[data-testid="stMetric"]{background:#100909;border:1px solid #661717;padding:12px;border-radius:12px}
.stButton>button{border:1px solid #b21f2d;border-radius:9px;background:#180909;color:#ff5656}
.stButton>button:hover{border-color:#ff4545;color:white;background:#310b0b}
.nf-banner{padding:18px 22px;border:1px solid #a51d2a;border-radius:14px;background:linear-gradient(110deg,#150707,#070707 65%);margin-bottom:18px}
.nf-sub{color:#b7a3a3;letter-spacing:.13em;font-size:.78rem}
</style>
""", unsafe_allow_html=True)
st.markdown('<div class="nf-banner"><div class="nf-sub">PASSIVE INTELLIGENCE // DEFENSIVE CYBER RESEARCH</div><h1>🌑 NIGHTFALL <span style="color:white">OSINT AI</span></h1><div class="nf-sub">OPEN-SOURCE INTELLIGENCE · EVIDENCE WORKSPACE · SECURITY CENTER</div></div>', unsafe_allow_html=True)
st.info("Use only for lawful research and systems you own or are authorized to assess. IP location is approximate; findings require analyst verification.")

with st.sidebar:
    st.markdown("## 🌑 NIGHTFALL")
    st.caption("ANALYST COMMAND CENTER · v1.0")
    page = st.radio("NAVIGATION", ["Dashboard","IP Intelligence","Username OSINT","Domain Intelligence","Security Center","Investigations","Privacy Center","Command Terminal"])
    st.divider()
    st.caption("PASSIVE / PUBLIC SOURCES ONLY")

def case_selector():
    cases = list_cases()
    labels = {f"#{c['id']} · {c['title']}": c["id"] for c in cases}
    labels["No case selected"] = None
    selected = st.selectbox("Attach results to investigation", list(labels), index=len(labels)-1)
    return labels[selected]

def save(case_id, kind, target, result):
    if case_id:
        add_evidence(case_id, kind, target, result)

def sources(items):
    if items:
        st.markdown("**Sources**")
        for item in items:
            st.markdown(f"- [{item['title']}]({item['url']})")

if page == "Dashboard":
    cases = list_cases()
    a,b,c = st.columns(3)
    a.metric("Investigation cases", len(cases))
    b.metric("Research mode", "Passive")
    c.metric("Platform", "Operational")
    st.subheader("Modules")
    st.markdown("- **IP Intelligence:** public network metadata and reputation references.\n- **Username OSINT:** curated public profile URL checks.\n- **Domain Intelligence:** RDAP, DNS, passive CT names and TLS.\n- **Security Center:** local phishing heuristics and breach-response guidance.\n- **Investigations:** evidence organization and exportable reports.\n- **Privacy Center:** account-hardening self-audit.")
    st.subheader("Recent investigations")
    st.dataframe(cases[:10], use_container_width=True, hide_index=True)
    st.caption("Separate verified observations from estimates. A username match is not proof of identity.")

elif page == "IP Intelligence":
    st.subheader("🌐 IP Intelligence")
    target = st.text_input("Public IPv4 / IPv6 address", placeholder="8.8.8.8")
    case_id = case_selector()
    if st.button("Investigate IP", type="primary"):
        try:
            ip = normalize_ip(target)
            result = investigate_ip(ip)
            st.session_state["ip_result"] = result
            save(case_id, "ip", ip, result)
        except Exception as exc:
            st.error(str(exc))
    result = st.session_state.get("ip_result")
    if result:
        st.warning("Geolocation is approximate network metadata, not a person's physical or residential location.")
        x,y,z = st.columns(3)
        x.metric("IP", result.get("ip","—"))
        y.metric("ASN", result.get("asn") or "Unknown")
        z.metric("Network type", result.get("network_type","Unknown"))
        st.json(result)
        sources(result.get("sources",[]))
        st.markdown("**Manual reputation lookups**")
        for link in result.get("reputation_links",[]):
            st.markdown(f"- [{link['name']}]({link['url']})")

elif page == "Username OSINT":
    st.subheader("👤 Username OSINT")
    target = st.text_input("Public username", placeholder="example_user")
    case_id = case_selector()
    if st.button("Check public profiles", type="primary"):
        try:
            user = normalize_username(target)
            result = check_username(user)
            st.session_state["username_result"] = result
            save(case_id, "username", user, result)
        except Exception as exc:
            st.error(str(exc))
    result = st.session_state.get("username_result")
    if result:
        st.warning("Profile reachability is not proof that one person controls accounts across services.")
        st.dataframe(result["profiles"], use_container_width=True, hide_index=True)
        st.caption(result["interpretation"])
        sources(result.get("sources",[]))

elif page == "Domain Intelligence":
    st.subheader("🛰️ Domain Intelligence")
    target = st.text_input("Domain name", placeholder="example.com")
    case_id = case_selector()
    c1,c2,c3 = st.columns(3)
    do_rdap = c1.button("RDAP + passive discovery", type="primary")
    do_dns = c2.button("DNS records")
    do_tls = c3.button("TLS certificate")
    try:
        domain = normalize_domain(target) if target else ""
        if do_rdap and domain:
            result = investigate_domain(domain)
            st.session_state["domain_result"] = result
            save(case_id, "domain", domain, result)
        if do_dns and domain:
            result = lookup_dns(domain)
            st.session_state["dns_result"] = result
            save(case_id, "dns", domain, result)
        if do_tls and domain:
            result = inspect_tls(domain)
            st.session_state["tls_result"] = result
            save(case_id, "tls", domain, result)
    except Exception as exc:
        st.error(str(exc))
    for key, label in [("domain_result","RDAP / passive discovery"),("dns_result","DNS records"),("tls_result","TLS certificate")]:
        if st.session_state.get(key):
            st.markdown(f"**{label}**")
            st.json(st.session_state[key])
            sources(st.session_state[key].get("sources",[]))

elif page == "Security Center":
    st.subheader("🛡️ Defensive Security Center")
    tab1,tab2 = st.tabs(["Phishing / URL analysis","Breach exposure guidance"])
    with tab1:
        target = st.text_input("URL to assess", placeholder="https://example.com/login")
        case_id = case_selector()
        if st.button("Analyze URL", type="primary"):
            try:
                result = analyze_url(target)
                st.session_state["url_result"] = result
                save(case_id, "url_analysis", target, result)
            except Exception as exc:
                st.error(str(exc))
        if st.session_state.get("url_result"):
            st.json(st.session_state["url_result"])
            st.caption("Heuristic indicators are not a definitive verdict. No page was fetched.")
    with tab2:
        st.warning("NIGHTFALL does not search leaked credential dumps or retrieve passwords.")
        st.markdown("For an account you own, visit [Have I Been Pwned](https://haveibeenpwned.com/) directly. Never enter a password into an exposure-checking site. Change reused passwords, enable MFA/passkeys, revoke unfamiliar sessions and review recovery settings.")

elif page == "Investigations":
    st.subheader("📁 Investigation Workspace")
    with st.form("new_case"):
        title = st.text_input("Case title", placeholder="Authorized assessment — example.org")
        notes = st.text_area("Scope / authorization notes")
        submitted = st.form_submit_button("Create investigation")
        if submitted:
            if title.strip():
                create_case(title.strip(), notes.strip())
                st.success("Investigation created.")
                st.rerun()
            else:
                st.error("A case title is required.")
    cases = list_cases()
    st.dataframe(cases, use_container_width=True, hide_index=True)
    if cases:
        chosen = st.selectbox("View evidence for case", [x["id"] for x in cases], format_func=lambda i: next(x["title"] for x in cases if x["id"] == i))
        evidence = list_evidence(chosen)
        st.dataframe(evidence, use_container_width=True, hide_index=True)
        if evidence:
            st.download_button("Download Markdown report", render_markdown_report(cases,evidence,chosen), file_name=f"nightfall_case_{chosen}.md", mime="text/markdown")
            st.download_button("Download JSON evidence", render_json_report(cases,evidence,chosen), file_name=f"nightfall_case_{chosen}.json", mime="application/json")

elif page == "Privacy Center":
    st.subheader("🔒 Privacy Center")
    st.caption("Self-audit your own accounts and public footprint.")
    checks = ["Use unique passwords in a password manager","Enable MFA or passkeys on primary email and important accounts","Review active sessions and revoke unfamiliar devices","Review public profile visibility and remove unnecessary personal details","Disable unnecessary location sharing and app permissions","Review recovery email addresses and phone numbers","Use official data-broker opt-out processes where applicable","Keep devices, operating systems and browsers updated"]
    for i,item in enumerate(checks):
        st.checkbox(item, key=f"privacy_{i}")
    st.info("Do not submit identity documents, passwords, private addresses, or other sensitive personal information to this dashboard.")

elif page == "Command Terminal":
    st.subheader("⌨️ NIGHTFALL Command Terminal")
    st.caption("Commands provide navigation guidance; data lookups require explicit submission in their module.")
    command = st.text_input("nightfall >", placeholder="/help")
    if st.button("Execute command"):
        parts = command.strip().split(maxsplit=1)
        cmd = parts[0].lower() if parts else ""
        routes = {
            "/help":"Available: /help /ip /username /domain /dns /whois /ssl /breach /phishing /report /privacy /clear",
            "/ip":"Open IP Intelligence.",
            "/username":"Open Username OSINT.",
            "/domain":"Open Domain Intelligence.",
            "/dns":"Open Domain Intelligence → DNS records.",
            "/whois":"Open Domain Intelligence → RDAP + passive discovery.",
            "/ssl":"Open Domain Intelligence → TLS certificate.",
            "/breach":"Open Security Center → Breach exposure guidance.",
            "/phishing":"Open Security Center → Phishing / URL analysis.",
            "/report":"Open Investigations to export a report.",
            "/privacy":"Open Privacy Center.",
            "/clear":"Refresh the page to clear terminal input."
        }
        st.success(routes.get(cmd, "Unknown command. Enter /help."))
