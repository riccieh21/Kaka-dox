import json, sqlite3
from pathlib import Path
from datetime import datetime, timezone
DB_DIR = Path(".nightfall")
DB_PATH = DB_DIR / "nightfall.db"
def connect():
    DB_DIR.mkdir(mode=0o700,parents=True,exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con
def init_db():
    with connect() as con:
        con.execute("CREATE TABLE IF NOT EXISTS cases (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,notes TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)")
        con.execute("CREATE TABLE IF NOT EXISTS evidence (id INTEGER PRIMARY KEY AUTOINCREMENT,case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,kind TEXT NOT NULL,target TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL)")
def create_case(title,notes=""):
    with connect() as con:
        cur=con.execute("INSERT INTO cases(title,notes,created_at) VALUES(?,?,?)",(title,notes,datetime.now(timezone.utc).isoformat()))
        return cur.lastrowid
def list_cases():
    with connect() as con: return [dict(x) for x in con.execute("SELECT * FROM cases ORDER BY id DESC").fetchall()]
def add_evidence(case_id,kind,target,payload):
    with connect() as con:
        con.execute("INSERT INTO evidence(case_id,kind,target,payload,created_at) VALUES(?,?,?,?,?)",(case_id,kind,target,json.dumps(payload,ensure_ascii=False),datetime.now(timezone.utc).isoformat()))
def list_evidence(case_id):
    with connect() as con: rows=con.execute("SELECT * FROM evidence WHERE case_id=? ORDER BY id DESC",(case_id,)).fetchall()
    result=[]
    for row in rows:
        item=dict(row); item["payload"]=json.loads(item["payload"]); result.append(item)
    return result
