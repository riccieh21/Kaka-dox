import os, requests
TIMEOUT = (4, 10)
USER_AGENT = os.getenv("NIGHTFALL_USER_AGENT", "NIGHTFALL-OSINT-AI/1.0 (defensive research)")
def get(url, *, params=None, headers=None):
    merged = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if headers: merged.update(headers)
    response = requests.get(url, params=params, headers=merged, timeout=TIMEOUT, allow_redirects=True)
    response.raise_for_status()
    return response
