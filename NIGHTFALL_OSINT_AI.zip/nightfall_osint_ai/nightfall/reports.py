import json
from datetime import datetime, timezone
def render_markdown_report(cases,evidence,case_id):
    case=next((c for c in cases if c["id"]==case_id),{})
    lines=[f"# NIGHTFALL OSINT Report — {case.get('title','Investigation')}","",
        f"- Case ID: {case_id}",f"- Generated: {datetime.now(timezone.utc).isoformat()}",
        "- Method: passive public-source research","","## Scope / notes",case.get("notes",""),"","## Evidence"]
    for item in evidence:
        lines += [f"### {item['kind']} — {item['target']}",f"- Captured: {item['created_at']}","","```json",
                  json.dumps(item["payload"],indent=2,ensure_ascii=False),"```",""]
    lines += ["## Analyst caveats","- Provider data may be incomplete or stale.",
              "- Estimates are not verified identity or physical-location evidence.",
              "- Validate findings independently before decisions."]
    return "\n".join(lines)
def render_json_report(cases,evidence,case_id):
    case=next((c for c in cases if c["id"]==case_id),{})
    return json.dumps({"platform":"NIGHTFALL OSINT AI","case":case,"evidence":evidence,
        "generated_at":datetime.now(timezone.utc).isoformat()},indent=2,ensure_ascii=False)
