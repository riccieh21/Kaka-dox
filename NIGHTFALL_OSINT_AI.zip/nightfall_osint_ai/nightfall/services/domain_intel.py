import socket, ssl
from datetime import datetime, timezone
import dns.resolver
from nightfall.http import get

def investigate_domain(domain):
    result = {"domain":domain,"rdap":None,"passive_subdomains":[],"limitations":[]}
    rdap_url = f"https://rdap.org/domain/{domain}"
    try:
        payload = get(rdap_url).json()
        result["rdap"] = {
            "handle":payload.get("handle"),"status":payload.get("status",[]),
            "nameservers":[x.get("ldhName") for x in payload.get("nameservers",[]) if x.get("ldhName")],
            "events":payload.get("events",[]),
            "note":"Registrant personal details are intentionally not extracted; RDAP disclosure varies."
        }
    except Exception as exc: result["limitations"].append(f"RDAP lookup unavailable: {exc}")
    try:
        rows = get("https://crt.sh/",params={"q":f"%.{domain}","output":"json"},headers={"Accept":"application/json"}).json()
        names = set()
        for row in rows[:2000]:
            for name in row.get("name_value","").splitlines():
                name = name.strip().lower().lstrip("*.")
                if name == domain or name.endswith("."+domain): names.add(name)
        result["passive_subdomains"] = sorted(names)[:250]
        result["ct_note"] = "Passive certificate-transparency observations; names may be historical or stale."
    except Exception as exc: result["limitations"].append(f"CT lookup unavailable: {exc}")
    result["sources"] = [{"title":"RDAP domain record","url":rdap_url},
                         {"title":"crt.sh certificate transparency search","url":f"https://crt.sh/?q=%25.{domain}"}]
    return result

def lookup_dns(domain):
    resolver = dns.resolver.Resolver()
    resolver.timeout, resolver.lifetime = 3, 6
    output = {"domain":domain,"records":{},"errors":{}}
    for kind in ("A","AAAA","MX","NS","TXT","CNAME","CAA"):
        try: output["records"][kind] = [r.to_text() for r in resolver.resolve(domain,kind)][:30]
        except (dns.resolver.NoAnswer,dns.resolver.NXDOMAIN): output["records"][kind] = []
        except Exception as exc: output["errors"][kind] = str(exc)
    output["sources"] = [{"title":"Google DNS public resolver reference","url":f"https://dns.google/resolve?name={domain}&type=A"}]
    return output

def inspect_tls(domain):
    context = ssl.create_default_context()
    result = {"domain":domain,"port":443}
    try:
        with socket.create_connection((domain,443),timeout=5) as sock:
            with context.wrap_socket(sock,server_hostname=domain) as tls:
                cert = tls.getpeercert()
                result.update({"tls_version":tls.version(),"cipher":tls.cipher(),
                    "subject":cert.get("subject"),"issuer":cert.get("issuer"),
                    "not_before":cert.get("notBefore"),"not_after":cert.get("notAfter"),
                    "san":[v for typ,v in cert.get("subjectAltName",[]) if typ=="DNS"][:50],
                    "verification":"Certificate chain verified by local trust store"})
    except Exception as exc: result.update({"error":str(exc),"verification":"Not verified"})
    result["retrieved_at"] = datetime.now(timezone.utc).isoformat()
    result["sources"] = [{"title":"TLS endpoint (port 443)","url":f"https://{domain}/"}]
    return result
