import ipaddress, socket
from urllib.parse import quote
from nightfall.http import get

def investigate_ip(ip):
    if not ipaddress.ip_address(ip).is_global:
        raise ValueError("Only public globally routable IPs are supported.")
    url = f"https://ipapi.co/{quote(ip, safe='')}/json/"
    data = {"ip": ip, "network_type": "Unknown", "vpn_proxy_hosting": "Not independently verified"}
    try:
        payload = get(url).json()
        if payload.get("error"): raise ValueError(payload.get("reason","Provider error"))
        data.update({
            "city": payload.get("city"), "region": payload.get("region"),
            "country": payload.get("country_name"), "country_code": payload.get("country_code"),
            "latitude_approx": payload.get("latitude"), "longitude_approx": payload.get("longitude"),
            "isp": payload.get("org"), "asn": payload.get("asn"),
            "postal_code": None, "source": "ipapi.co"
        })
    except Exception as exc:
        data["lookup_error"] = str(exc)
    try: data["reverse_dns"] = socket.gethostbyaddr(ip)[0]
    except (socket.herror, socket.gaierror, OSError): data["reverse_dns"] = None
    data["reputation_links"] = [
        {"name":"AbuseIPDB","url":f"https://www.abuseipdb.com/check/{ip}"},
        {"name":"VirusTotal","url":f"https://www.virustotal.com/gui/ip-address/{ip}"},
        {"name":"Cisco Talos","url":f"https://talosintelligence.com/reputation_center/lookup?search={ip}"}
    ]
    data["sources"] = [{"title":"ipapi.co public IP API","url":url}] + data["reputation_links"]
    data["confidence_note"] = "Geolocation and network ownership are provider estimates. VPN/proxy status is not asserted without a dedicated verified source."
    return data
