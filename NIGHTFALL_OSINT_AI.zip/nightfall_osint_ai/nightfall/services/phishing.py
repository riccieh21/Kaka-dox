import ipaddress
from urllib.parse import urlparse
SHORTENERS = {"bit.ly","tinyurl.com","t.co","goo.gl","ow.ly","is.gd","buff.ly","cutt.ly"}
TERMS = {"login","verify","account","secure","password","wallet","billing","update","signin"}
def analyze_url(value):
    raw = value.strip()
    if not raw: raise ValueError("Enter a URL.")
    parsed = urlparse(raw if "://" in raw else "https://"+raw)
    if parsed.scheme not in ("http","https") or not parsed.hostname: raise ValueError("Only valid HTTP/HTTPS URLs can be assessed.")
    host = parsed.hostname.lower().rstrip(".")
    findings, score = [], 0
    if parsed.scheme != "https": score += 15; findings.append("URL does not use HTTPS.")
    if "@" in parsed.netloc: score += 25; findings.append("URL contains user-info syntax that can disguise the destination.")
    if host.startswith("xn--") or ".xn--" in host: score += 20; findings.append("Punycode hostname; inspect for lookalike characters.")
    try: ipaddress.ip_address(host); score += 20; findings.append("Host is an IP literal.")
    except ValueError: pass
    if host in SHORTENERS: score += 15; findings.append("Known URL shortener obscures the destination.")
    if len(host)>45: score += 10; findings.append("Unusually long hostname.")
    if host.count("-")>=3: score += 10; findings.append("Hostname contains multiple hyphens.")
    matched = sorted(x for x in TERMS if x in host+parsed.path.lower())
    if matched: score += min(20,len(matched)*5); findings.append("Sensitive-action wording: "+", ".join(matched))
    if len(parsed.query)>150: score += 5; findings.append("Long query string may contain tracking tokens.")
    score = min(score,100)
    return {"url":parsed.geturl(),"hostname":host,"scheme":parsed.scheme,
        "heuristic_score_0_100":score,
        "indicator_band":"Elevated indicators" if score>=45 else "Some indicators" if score>=20 else "Few heuristic indicators",
        "findings":findings or ["No configured heuristic indicators detected."],
        "limitations":"Local heuristic only; not a reputation verdict or proof of safety. No page was fetched.",
        "safe_handling":"Do not open suspicious links. Verify using the organization's known official website or security team."}
