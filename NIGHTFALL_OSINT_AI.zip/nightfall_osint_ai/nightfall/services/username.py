from concurrent.futures import ThreadPoolExecutor, as_completed
from nightfall.http import get

SITES = {
    "GitHub":"https://github.com/{username}",
    "GitLab":"https://gitlab.com/{username}",
    "Reddit":"https://www.reddit.com/user/{username}/",
    "Medium":"https://medium.com/@{username}",
    "Pinterest":"https://www.pinterest.com/{username}/",
    "Twitch":"https://www.twitch.tv/{username}"
}
def _check(item):
    name, template, username = item
    url = template.format(username=username)
    try:
        response = get(url, headers={"Accept":"text/html,*/*"})
        status = "Reachable — manual verification required" if response.status_code < 400 else "Not confirmed"
        return {"platform":name,"status":status,"url":url,"http_status":response.status_code}
    except Exception:
        return {"platform":name,"status":"Unknown — blocked or unavailable","url":url,"http_status":None}

def check_username(username):
    items = [(n,t,username) for n,t in SITES.items()]
    results = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        futures = [pool.submit(_check,x) for x in items]
        for future in as_completed(futures): results.append(future.result())
    results.sort(key=lambda x:x["platform"])
    return {"username":username,"profiles":results,
            "interpretation":"URL reachability is not proof of account ownership, identity, or availability. Sites may block automated requests or return generic pages.",
            "sources":[{"title":f"{x['platform']} public profile URL","url":x["url"]} for x in results]}
