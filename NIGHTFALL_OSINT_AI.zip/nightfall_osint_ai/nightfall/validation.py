import ipaddress, re
from urllib.parse import urlparse

def normalize_ip(value):
    try:
        ip = ipaddress.ip_address(value.strip())
    except ValueError as exc:
        raise ValueError("Enter a valid IPv4 or IPv6 address.") from exc
    if not ip.is_global:
        raise ValueError("Only globally routable public IP addresses are supported.")
    return str(ip)

def normalize_domain(value):
    raw = value.strip().lower().rstrip(".")
    if "://" in raw:
        raw = urlparse(raw).hostname or ""
    if raw.startswith("www."):
        raw = raw[4:]
    if not raw or len(raw) > 253 or "/" in raw or "@" in raw:
        raise ValueError("Enter a valid domain name without paths or credentials.")
    try:
        raw = raw.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ValueError("Invalid internationalized domain name.") from exc
    labels = raw.split(".")
    if len(labels) < 2 or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", x) for x in labels):
        raise ValueError("Enter a valid fully-qualified domain name.")
    return raw

def normalize_username(value):
    value = value.strip().lstrip("@")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{2,30}", value):
        raise ValueError("Username must be 2–30 characters: letters, numbers, dot, underscore or hyphen.")
    return value
