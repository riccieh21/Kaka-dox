import unittest
from nightfall.validation import normalize_ip, normalize_domain, normalize_username
class ValidationTests(unittest.TestCase):
    def test_public_ip(self): self.assertEqual(normalize_ip("8.8.8.8"),"8.8.8.8")
    def test_private_ip_rejected(self):
        with self.assertRaises(ValueError): normalize_ip("192.168.1.1")
    def test_domain(self): self.assertEqual(normalize_domain("Example.COM"),"example.com")
    def test_username(self): self.assertEqual(normalize_username("@alice_01"),"alice_01")
if __name__=="__main__": unittest.main()
